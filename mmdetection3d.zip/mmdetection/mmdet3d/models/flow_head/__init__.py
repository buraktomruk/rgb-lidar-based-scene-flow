
# from mmdet.models.necks.fpn import FPN
from .flownet3d_head import FlowNet3D

__all__ = ['FlowNet3D']
