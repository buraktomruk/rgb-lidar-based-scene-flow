import mmcv
import torch
from mmcv.image import tensor2imgs
from os import path as osp

from mmdet3d.models import Base3DDetector, Base3DSegmentor


def single_gpu_test(model,
                    data_loader,
                    show=False,
                    out_dir=None,
                    show_score_thr=0.3):
    """Test model with single gpu.

    This method tests model with single gpu and gives the 'show' option.
    By setting ``show=True``, it saves the visualization results under
    ``out_dir``.

    Args:
        model (nn.Module): Model to be tested.
        data_loader (nn.Dataloader): Pytorch data loader.
        show (bool): Whether to save viualization results.
            Default: True.
        out_dir (str): The path to save visualization results.
            Default: None.

    Returns:
        list[dict]: The prediction results.
    """
    model.eval()
    results = []
    dataset = data_loader.dataset
    prog_bar = mmcv.ProgressBar(len(dataset))
    for i, data in enumerate(data_loader):
        with torch.no_grad():
            result = model(return_loss=False, rescale=True, **data)

        if show:
            # Visualize the results of MMDetection3D model
            # 'show_results' is MMdetection3D visualization API
            if isinstance(model.module, (Base3DDetector, Base3DSegmentor)):
                model.module.show_results(data, result, out_dir)
            # Visualize the results of MMDetection model
            # 'show_result' is MMdetection visualization API
            else:
                batch_size = len(result)
                if batch_size == 1 and isinstance(data['img'][0],
                                                  torch.Tensor):
                    img_tensor = data['img'][0]
                else:
                    img_tensor = data['img'][0].data[0]
                img_metas = data['img_metas'][0].data[0]
                imgs = tensor2imgs(img_tensor, **img_metas[0]['img_norm_cfg'])
                assert len(imgs) == len(img_metas)

                for i, (img, img_meta) in enumerate(zip(imgs, img_metas)):
                    h, w, _ = img_meta['img_shape']
                    img_show = img[:h, :w, :]

                    ori_h, ori_w = img_meta['ori_shape'][:-1]
                    img_show = mmcv.imresize(img_show, (ori_w, ori_h))

                    if out_dir:
                        out_file = osp.join(out_dir, img_meta['ori_filename'])
                    else:
                        out_file = None

                    model.module.show_result(
                        img_show,
                        result[i],
                        show=show,
                        out_file=out_file,
                        score_thr=show_score_thr)
        results.extend(result)

        batch_size = len(result)
        for _ in range(batch_size):
            prog_bar.update()
    return results









# import mmcv
# import torch
# from mmcv.image import tensor2imgs
# from os import path as osp
# import os
# from mmdet3d.models import Base3DDetector, Base3DSegmentor
# import json

# def single_gpu_test(model,
#                     data_loader,
#                     show=False,
#                     out_dir=None,
#                     validation_path = None,
#                     show_score_thr=0.3):
#     """Test model with single gpu.

#     This method tests model with single gpu and gives the 'show' option.
#     By setting ``show=True``, it saves the visualization results under
#     ``out_dir``.

#     Args:
#         model (nn.Module): Model to be tested.
#         data_loader (nn.Dataloader): Pytorch data loader.
#         show (bool): Whether to save viualization results.
#             Default: True.
#         out_dir (str): The path to save visualization results.
#             Default: None.

#     Returns:
#         list[dict]: The prediction results.
#     """
#     model.eval()
#     results = []
#     dataset = data_loader.dataset
#     #prog_bar = mmcv.ProgressBar(len(dataset))
    
#     losses = {} 
#     nsamples = len(dataset)/2
#     dataset_len = len(dataset)
#     #cntr = 0
#     loss_val = 0
#     print('Validation dataset size: ', dataset_len)
#     print('Sequential pair size: ', int(nsamples))
#     prog_bar = mmcv.ProgressBar(len(dataset))
    
#     for i, data in enumerate(data_loader):
#         #cntr = cntr + len(data)
#         if i < nsamples:
#             with torch.no_grad():
#                 result = model(return_loss=False, rescale=True, **data)
#                 loss_val = loss_val + (result.item() / dataset_len)
#         else: 
#             break

#         batch_size = 2
#         for _ in range(batch_size):
#             prog_bar.update()
#     loss_val = round(loss_val, 5)
#     print('Loss: ', loss_val)
#     #return results
