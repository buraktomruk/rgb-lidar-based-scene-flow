# Flow Head

## Dependencies

```
kaolin v0.1
```

## How to use?

Put this folder into `${MMDETECTION3D}/mmdet3d/models` and update relavant files according to the [Tutorial](https://github.com/open-mmlab/mmdetection3d/blob/master/docs/tutorials/customize_models.md)
